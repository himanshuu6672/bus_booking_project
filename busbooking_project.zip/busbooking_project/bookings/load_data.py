import json
from bookings.models import Bus, Route, Trip

def run():
    with open('bookings_data.json', 'r') as file:
        data = json.load(file)

    for item in data:
        bus_data = item['bus']
        route_data = item['route']
        trip_data = item['trip']

        # Create or get Bus
        bus, _ = Bus.objects.get_or_create(
            bus_number=bus_data['bus_number'],
            defaults={
                'operator': bus_data['operator'],
                'capacity': bus_data['capacity']
            }
        )

        # Create or get Route
        route, _ = Route.objects.get_or_create(
            origin=route_data['origin'],
            destination=route_data['destination']
        )

        # Create Trip
        Trip.objects.create(
            bus=bus,
            route=route,
            date=trip_data['date'],
            price=trip_data['price'],
            available_seats=trip_data['available_seats']
        )

    print("✅ Data loaded successfully!")
