from django.contrib import admin
from .models import Route, Bus, Trip, Booking


@admin.register(Route)
class RouteAdmin(admin.ModelAdmin):
    list_display = ('origin', 'destination', 'distance_km')
    search_fields = ('origin', 'destination')


@admin.register(Bus)
class BusAdmin(admin.ModelAdmin):
    list_display = ('name', 'capacity')
    search_fields = ('name',)


@admin.register(Trip)
class TripAdmin(admin.ModelAdmin):
    list_display = ('route', 'bus', 'date', 'price', 'available_seats')
    list_filter = ('date', 'route')
    ordering = ('date',)


@admin.register(Booking)
class BookingAdmin(admin.ModelAdmin):
    list_display = ('name', 'trip', 'email', 'seats')
    search_fields = ('name', 'email')
    list_filter = ('trip',)
