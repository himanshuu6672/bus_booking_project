from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.http import JsonResponse

from .models import Trip, Booking
from .forms import SearchForm


# -------------------------------
# SEARCH VIEW
# -------------------------------
def search_view(request):
    form = SearchForm(request.GET or None)
    trips = Trip.objects.select_related('bus', 'route').all()

    if form.is_valid():
        origin = form.cleaned_data.get('origin', '').strip()
        destination = form.cleaned_data.get('destination', '').strip()
        date = form.cleaned_data.get('date')

        if origin:
            trips = trips.filter(route__origin__icontains=origin)
        if destination:
            trips = trips.filter(route__destination__icontains=destination)
        if date:
            trips = trips.filter(date=date)

    # AJAX (for fetch requests)
    if request.headers.get('x-requested-with') == 'XMLHttpRequest':
        if not trips.exists():
            return JsonResponse({'results': [], 'message': 'No trips found.'})

        data = [
            {
                'id': trip.id,
                'route': f"{trip.route.origin} → {trip.route.destination}",
                'bus': getattr(trip.bus, 'name', 'N/A'),
                'operator': getattr(trip.bus, 'operator', 'N/A'),
                'departure': trip.date.strftime("%Y-%m-%d"),
                'price': float(trip.price),
                'seats': trip.available_seats,
                'book_url': f"/book/{trip.id}/",
            }
            for trip in trips
        ]
        return JsonResponse({'results': data})

    return render(request, 'bookings/search.html', {'form': form, 'trips': trips})


# -------------------------------
# BOOK TRIP VIEW
# -------------------------------
@login_required
def book_trip(request, trip_id):
    trip = get_object_or_404(Trip, id=trip_id)

    if request.method == "GET":
        return render(request, "bookings/book_trip.html", {"trip": trip})

    # POST → handle booking
    name = request.POST.get("name")
    email = request.POST.get("email")
    seats = int(request.POST.get("seats", 1))

    if trip.available_seats < seats:
        messages.error(request, "Not enough seats available.")
        return redirect("bookings:book_trip", trip_id=trip.id)

    # Prevent duplicate bookings by the same user
    if Booking.objects.filter(user=request.user, trip=trip).exists():
        messages.warning(request, "You have already booked this trip.")
        return redirect("bookings:my_bookings")

    # ✅ Create a booking linked to the user
    Booking.objects.create(
        user=request.user,
        trip=trip,
        name=name,
        email=email,
        seats=seats
    )

    messages.success(
        request,
        f"Successfully booked {seats} seat(s) on {trip.route.origin} → {trip.route.destination}!"
    )
    return redirect("bookings:my_bookings")


# -------------------------------
# MY BOOKINGS VIEW
# -------------------------------
@login_required
def my_bookings(request):
    bookings = Booking.objects.filter(user=request.user).select_related(
        'trip', 'trip__route', 'trip__bus'
    )
    return render(request, "bookings/my_booking.html", {"bookings": bookings})

@login_required

def cancel_booking(request, booking_id):
    """
    Cancels a user's booking.
    """
    booking = get_object_or_404(Booking, id=booking_id, user=request.user)
    booking.delete()
    messages.success(request, "Your booking has been cancelled successfully.")
    return redirect("bookings:my_bookings")