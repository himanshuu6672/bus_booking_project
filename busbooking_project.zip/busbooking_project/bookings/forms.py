from django import forms

class SearchForm(forms.Form):
    origin = forms.CharField(
        max_length=100,
        label="From",
        widget=forms.TextInput(attrs={"placeholder": "Enter origin"})
    )
    destination = forms.CharField(
        max_length=100,
        label="To",
        widget=forms.TextInput(attrs={"placeholder": "Enter destination"})
    )
    date = forms.DateField(
        required=False,
        widget=forms.DateInput(attrs={"type": "date"})
    )
