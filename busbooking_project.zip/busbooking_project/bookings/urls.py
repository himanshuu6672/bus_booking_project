'''from django.urls import path
from . import views

app_name = 'bookings'

urlpatterns = [
    path('', views.search_view, name='search'),          # Search page (default)
    path('book/<int:trip_id>/', views.book_trip, name='book'),  # Booking page (optional placeholder)
]
'''
from django.urls import path
from . import views

app_name = 'bookings'

urlpatterns = [
    path('', views.search_view, name='search'),  # ← this line causes the error
    path("book/<int:trip_id>/", views.book_trip, name="book_trip"),
    path('my-bookings/', views.my_bookings, name='my_bookings'),
    path("cancel/<int:booking_id>/", views.cancel_booking, name="cancel_booking"),
]
