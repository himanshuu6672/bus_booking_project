from django.db import models
from django.contrib.auth.models import User


# -------------------------------
# ROUTE MODEL
# -------------------------------
class Route(models.Model):
    origin = models.CharField(max_length=100)
    destination = models.CharField(max_length=100)
    distance_km = models.FloatField()

    def __str__(self):
        return f"{self.origin} → {self.destination}"


# -------------------------------
# BUS MODEL
# -------------------------------
class Bus(models.Model):
    # Allowing null/blank for legacy DB data
    name = models.CharField(max_length=100, null=True, blank=True)
    operator = models.CharField(max_length=100, null=True, blank=True)
    capacity = models.IntegerField()

    def __str__(self):
        return f"{self.name or 'Unnamed Bus'} ({self.operator or 'Unknown Operator'})"


# -------------------------------
# TRIP MODEL
# -------------------------------
class Trip(models.Model):
    route = models.ForeignKey(Route, on_delete=models.CASCADE)
    bus = models.ForeignKey(Bus, on_delete=models.CASCADE)
    date = models.DateField()
    price = models.DecimalField(max_digits=8, decimal_places=2)

    def __str__(self):
        return f"{self.route} on {self.date}"

    @property
    def available_seats(self):
        """Calculate remaining available seats."""
        booked = Booking.objects.filter(trip=self).aggregate(total=models.Sum("seats"))["total"] or 0
        return self.bus.capacity - booked


# -------------------------------
# BOOKING MODEL
# -------------------------------
class Booking(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE, null=True, blank=True)
    trip = models.ForeignKey(Trip, on_delete=models.CASCADE)
    name = models.CharField(max_length=100)
    email = models.EmailField()
    seats = models.PositiveIntegerField(default=1)

    def __str__(self):
        return f"{self.name} - {self.trip}"
